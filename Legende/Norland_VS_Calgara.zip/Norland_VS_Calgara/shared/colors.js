const $STR = '#DC241C';
const $DEX = '#1CAC24';
const $QCK = '#4C4CFF';
const $PSY = '#ECAC04';
const $INT = '#A916B6';